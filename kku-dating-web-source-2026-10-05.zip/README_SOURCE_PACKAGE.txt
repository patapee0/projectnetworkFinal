KKU Dating - Web Source Package

Included: Flutter web app source (lib, web, tests), web assets, optional Cloudflare Worker source, Firebase configuration, Firestore rules/indexes, Storage rules, and dependency manifests.
Excluded: generated build output, caches, node_modules, Android/iOS/desktop platform projects, uploaded files, and environment/secret files.

Build: In kku_dating_flutter, run `flutter pub get`, then `flutter build web --release`.
Run locally: `flutter run -d chrome`.

Deploy ONLY to https://dating-test-final.web.app from kku_dating_flutter:
`firebase deploy --only hosting:dating-test-final --project projectnetwork-c403e`
The site target is configured in .firebaserc and firebase.json. Avoid unscoped Hosting deploy commands if publishing only this site.

Firebase, Cloudinary, and optional Cloudflare Worker services need console-side setup. Worker secrets are intentionally excluded. The optional Worker allowed-origin configuration may need the target hostname added before using Worker-only features.